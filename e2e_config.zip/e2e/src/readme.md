# Pruebas E2E - BitacoraFit

En este proyecto se definen los escenarios E2E principales de la app:

- Inicio de sesión del usuario.
- Registro de un entrenamiento.
- Visualización del historial.

Por motivos de alcance del curso, los escenarios están escritos con sintaxis Jasmine
y se ejecutan de forma conceptual, pero la estructura permite migrar fácilmente
a un runner real como Cypress o Playwright.
